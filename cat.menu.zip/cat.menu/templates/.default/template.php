<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$this->setFrameMode(true);
?>
<?
$my_sections = CIBlockSection::GetList (
	  Array("SECTION" => "ASC"),
      Array("IBLOCK_ID" => $arParams["IBLOCK_ID"], "ACTIVE" => "Y" , "<=DEPTH_LEVEL" => $arParams["MAX_LEVEL"]),
      false,
      Array('ID', 'NAME', 'CODE' , 'DEPTH_LEVEL' , 'IBLOCK_SECTION_ID')
   );

$my_element = CIBlockElement::GetList(
 Array("IBLOCK_SECTION_ID"=>"ASC"),
 Array("IBLOCK_ID" => $arParams["IBLOCK_ID"], "ACTIVE" => "Y" , "=PROPERTY_OK" => 'Y', "!SECTION_ID" => ""),
 false,
 false,
 Array('ID', 'NAME' ,'CODE', 'IBLOCK_SECTION_ID' , 'DETAIL_PAGE_URL','PROPERTY_OK')
);

 while($ar_item = $my_element->GetNext()){

	$menu_element[$ar_item['IBLOCK_SECTION_ID']][$ar_item['ID']]['ID']   = $ar_item['ID'];
	$menu_element[$ar_item['IBLOCK_SECTION_ID']][$ar_item['ID']]['NAME'] = $ar_item['NAME'];
	$menu_element[$ar_item['IBLOCK_SECTION_ID']][$ar_item['ID']]['CODE'] = $ar_item['CODE'];
	$menu_element[$ar_item['IBLOCK_SECTION_ID']][$ar_item['ID']]['URL']  = $ar_item['DETAIL_PAGE_URL'];

	
 }


 $menu_i = 0 ;	
   while($ar_fields = $my_sections->GetNext())
   {
   	$url = str_replace(array("#SECTION_ID#", "#SECTION_CODE#", "#SITE_DIR#"), array($ar_fields['ID'], $ar_fields['CODE'], ''),$arResult['SECTION_PAGE_URL']);
   	$menu_id[$menu_i] = $ar_fields['ID'];;
   	$menu_list[$ar_fields['DEPTH_LEVEL']][$menu_i]['ID'] = $ar_fields['ID'];
   	$menu_list[$ar_fields['DEPTH_LEVEL']][$menu_i]['IBLOCK_SECTION_ID'] = $ar_fields['IBLOCK_SECTION_ID'];
   	$menu_list[$ar_fields['DEPTH_LEVEL']][$menu_i]['NAME'] = $ar_fields['NAME'];
   	$menu_list[$ar_fields['DEPTH_LEVEL']][$menu_i]['CODE'] = $ar_fields['CODE'];
   	$menu_list[$ar_fields['DEPTH_LEVEL']][$menu_i]['DEPTH_LEVEL'] = $ar_fields['DEPTH_LEVEL'];
   	$menu_list[$ar_fields['DEPTH_LEVEL']][$menu_i]['URL'] = $url;

   	$menu_i ++;         	
	}

?>




<div class="menu-catalog">

	<?	if (count($menu_list[1]) > 0 ){
		foreach($menu_list[1] as $menu_item_1){?>
		<ul>
			<li>
				<a href="<?=$menu_item_1[URL]?>"> <?=$menu_item_1[NAME]?> </a>

	<?	if (count($menu_element[$menu_item_1[ID]]) > 0 ){?>
<div class="top">
		<?foreach($menu_element[$menu_item_1[ID]] as $menu_el){?>
						
								<span> <a href='<?=$menu_el[URL]?>'><?=$menu_el[NAME]?></a></span>
						
		<?}?>
</div>	
	<?}?>


	<?	if (count($menu_list[2]) > 0 ){?>
					<ul>
					<?foreach($menu_list[2] as $menu_item_2){?>
						<?if ($menu_item_2[IBLOCK_SECTION_ID] == $menu_item_1[ID]){
							echo '<li><a href="'.$menu_item_2[URL].'"> '.$menu_item_2[NAME].'</a></li>';
						
						?>


	<?	if (count($menu_element[$menu_item_2[ID]]) > 0 ){?>
<div class="top">
		<?foreach($menu_element[$menu_item_2[ID]] as $menu_el){?>
						
								<span> <a href='<?=$menu_el[URL]?>'><?=$menu_el[NAME]?><a></span>
						
		<?}?>
</div>	
	<?}?>



							
	<?	if (count($menu_list[3]) > 0 ){?>
						<ul>
							<?foreach($menu_list[3] as $menu_item_3){?>
						
								<?if ($menu_item_3[IBLOCK_SECTION_ID] == 2){
										echo '<li><a href="'.$menu_item_3[URL].'"> '.$menu_item_3[NAME].$menu_item_3[IBLOCK_SECTION_ID].$menu_item_2[ID].'</a></li>';
								}?>
							<?};?>


	<?	if (count($menu_element[$menu_item_3[ID]]) > 0 ){?>
<div class="top">
		<?foreach($menu_element[$menu_item_3[ID]] as $menu_el){?>
						
								<span> <a href='<?=$menu_el[URL]?>'><?=$menu_el[NAME]?><a></span>
						
		<?}?>
</div>	
	<?}?>

						</ul>

	<?}?>
					<?};?>
				</ul>
				<?}?>
				<?}?>


			</li>
		</ul>
	<?};
	}
	?>

</div>
