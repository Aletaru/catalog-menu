<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateParameters = array(
		"MAX_LEVEL" => Array(
			"NAME"=>GetMessage("MAX_LEVEL_NAME"),
			"TYPE" => "LIST",
			"DEFAULT"=>'1',
			"PARENT" => "ADDITIONAL_SETTINGS",
			"VALUES" => Array(
				1 => "1",
				2 => "2",
				3 => "3",
	
			),
			
		),
);
?>
