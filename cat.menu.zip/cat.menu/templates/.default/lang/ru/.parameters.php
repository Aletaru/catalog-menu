<?
$MESS["MAX_LEVEL_NAME"] = "Глубина меню";
?>