<?
$MESS ['T_NEWS_NEWS_NA'] = "Section is not found";
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Information blocks module is not installed";
?>