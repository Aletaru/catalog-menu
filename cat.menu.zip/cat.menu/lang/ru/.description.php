<?
$MESS ['T_IBLOCK_DESC_LIST'] = "Список новостей";
$MESS ['T_IBLOCK_DESC_LIST_DESC'] = "Список новостей из одного информационного блока.";
$MESS ['T_IBLOCK_DESC_NEWS'] = "Статьи и новости";
?>