<?
$MESS["IBLOCK_CACHE_FILTER"] = "Кешировать при установленном фильтре";
$MESS["MAX_LEVEL_NAME"] = "Глубина меню";

$MESS["T_IBLOCK_DESC_ASC"] = "По возрастанию";
$MESS["T_IBLOCK_DESC_DESC"] = "По убыванию";
$MESS["T_IBLOCK_DESC_FID"] = "ID";
$MESS["T_IBLOCK_DESC_FNAME"] = "Название";
$MESS["T_IBLOCK_DESC_FACT"] = "Дата начала активности";
$MESS["T_IBLOCK_DESC_FSORT"] = "Сортировка";
$MESS["T_IBLOCK_DESC_FTSAMP"] = "Дата последнего изменения";
$MESS["T_IBLOCK_DESC_IBORD1"] = "Поле для первой сортировки новостей";
$MESS["T_IBLOCK_DESC_IBBY1"] = "Направление для первой сортировки новостей";
$MESS["T_IBLOCK_DESC_IBORD2"] = "Поле для второй сортировки новостей";
$MESS["T_IBLOCK_DESC_IBBY2"] = "Направление для второй сортировки новостей";
$MESS["T_IBLOCK_DESC_LIST_ID"] = "Код информационного блока";
$MESS["T_IBLOCK_DESC_LIST_TYPE"] = "Тип информационного блока (используется только для проверки)";
$MESS["T_IBLOCK_DESC_LIST_CONT"] = "Количество новостей на странице";
$MESS["T_IBLOCK_DESC_DETAIL_PAGE_URL"] = "URL страницы детального просмотра (по умолчанию - из настроек инфоблока)";
$MESS["T_IBLOCK_DESC_INCLUDE_IBLOCK_INTO_CHAIN"] = "Включать инфоблок в цепочку навигации";
$MESS["T_IBLOCK_PROPERTY"] = "Свойства";
$MESS["T_IBLOCK_FILTER"] = "Фильтр";
$MESS["IBLOCK_FIELD"] = "Поля";
$MESS["T_IBLOCK_DESC_ACTIVE_DATE_FORMAT"] = "Формат показа даты";
$MESS["T_IBLOCK_DESC_PAGER_NEWS"] = "Новости";
$MESS["T_IBLOCK_DESC_PREVIEW_TRUNCATE_LEN"] = "Максимальная длина анонса для вывода (только для типа текст)";
$MESS["T_IBLOCK_DESC_HIDE_LINK_WHEN_NO_DETAIL"] = "Скрывать ссылку, если нет детального описания";
$MESS["IBLOCK_SECTION_ID"] = "ID раздела";
$MESS["IBLOCK_SECTION_CODE"] = "Код раздела";
$MESS["T_IBLOCK_DESC_ADD_SECTIONS_CHAIN"] = "Включать раздел в цепочку навигации";
$MESS["T_IBLOCK_DESC_CHECK_DATES"] = "Показывать только активные на данный момент элементы";
$MESS["CP_BNL_CACHE_GROUPS"] = "Учитывать права доступа";
$MESS["CP_BNL_INCLUDE_SUBSECTIONS"] = "Показывать элементы подразделов раздела";
$MESS["CP_BNL_SET_BROWSER_TITLE"] = "Устанавливать заголовок окна браузера";
$MESS["CP_BNL_SET_META_KEYWORDS"] = "Устанавливать ключевые слова страницы";
$MESS["CP_BNL_SET_META_DESCRIPTION"] = "Устанавливать описание страницы";
$MESS["CP_BNL_SET_LAST_MODIFIED"] = "Устанавливать в заголовках ответа время модификации страницы";
?>